package com.example.res

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "recipes.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "recipes"
        private const val COLUMN_ID = "idMeal"
        private const val COLUMN_NAME = "strMeal"
        private const val COLUMN_CATEGORY = "strCategory"
        private const val COLUMN_AREA = "strArea"
        private const val COLUMN_INSTRUCTIONS = "strInstructions"
        private const val COLUMN_THUMB = "strMealThumb"
        private const val COLUMN_FAVORITE = "isFavorite"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_ID TEXT PRIMARY KEY, "
                + "$COLUMN_NAME TEXT, "
                + "$COLUMN_CATEGORY TEXT, "
                + "$COLUMN_AREA TEXT, "
                + "$COLUMN_INSTRUCTIONS TEXT, "
                + "$COLUMN_THUMB TEXT, "
                + "$COLUMN_FAVORITE INTEGER DEFAULT 0)")
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addRecipe(recipe: Recipe): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_ID, recipe.idMeal)
            put(COLUMN_NAME, recipe.strMeal)
            put(COLUMN_CATEGORY, recipe.strCategory)
            put(COLUMN_AREA, recipe.strArea)
            put(COLUMN_INSTRUCTIONS, recipe.strInstructions)
            put(COLUMN_THUMB, recipe.strMealThumb)
            put(COLUMN_FAVORITE, if (recipe.isFavorite) 1 else 0)
        }
        val result = db.insert(TABLE_NAME, null, contentValues)
        db.close()
        return result
    }

    fun getRecipes(): List<Recipe> {
        val recipeList = mutableListOf<Recipe>()
        val db = this.readableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(selectQuery, null)

        val idIndex = cursor.getColumnIndex(COLUMN_ID)
        val nameIndex = cursor.getColumnIndex(COLUMN_NAME)
        val categoryIndex = cursor.getColumnIndex(COLUMN_CATEGORY)
        val areaIndex = cursor.getColumnIndex(COLUMN_AREA)
        val instructionsIndex = cursor.getColumnIndex(COLUMN_INSTRUCTIONS)
        val thumbIndex = cursor.getColumnIndex(COLUMN_THUMB)
        val favoriteIndex = cursor.getColumnIndex(COLUMN_FAVORITE)

        if (idIndex != -1 && nameIndex != -1 && categoryIndex != -1 && areaIndex != -1 &&
            instructionsIndex != -1 && thumbIndex != -1 && favoriteIndex != -1) {

            if (cursor.moveToFirst()) {
                do {
                    val recipe = Recipe(
                        idMeal = cursor.getString(idIndex),
                        strMeal = cursor.getString(nameIndex),
                        strCategory = cursor.getString(categoryIndex),
                        strArea = cursor.getString(areaIndex),
                        strInstructions = cursor.getString(instructionsIndex),
                        strMealThumb = cursor.getString(thumbIndex),
                        isFavorite = cursor.getInt(favoriteIndex) == 1
                    )
                    recipeList.add(recipe)
                } while (cursor.moveToNext())
            }
        } else {
            Log.e("DatabaseHelper", "One or more columns not found")
        }

        cursor.close()
        db.close()
        return recipeList
    }

    fun updateRecipe(recipe: Recipe): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_NAME, recipe.strMeal)
            put(COLUMN_CATEGORY, recipe.strCategory)
            put(COLUMN_AREA, recipe.strArea)
            put(COLUMN_INSTRUCTIONS, recipe.strInstructions)
            put(COLUMN_THUMB, recipe.strMealThumb)
            put(COLUMN_FAVORITE, if (recipe.isFavorite) 1 else 0)
        }
        val result = db.update(TABLE_NAME, contentValues, "$COLUMN_ID = ?", arrayOf(recipe.idMeal))
        db.close()
        return result
    }

    fun deleteRecipe(recipeId: String): Int {
        val db = this.writableDatabase
        val result = db.delete(TABLE_NAME, "$COLUMN_ID = ?", arrayOf(recipeId))
        db.close()
        return result
    }

    fun getAllUserRecipes(): List<Recipe> {
        val recipes = mutableListOf<Recipe>()
        val db = this.readableDatabase
        val cursor = db.query(TABLE_NAME, null, null, null, null, null, null)
        val idIndex = cursor.getColumnIndex(COLUMN_ID)
        val nameIndex = cursor.getColumnIndex(COLUMN_NAME)
        val categoryIndex = cursor.getColumnIndex(COLUMN_CATEGORY)
        val areaIndex = cursor.getColumnIndex(COLUMN_AREA)
        val instructionsIndex = cursor.getColumnIndex(COLUMN_INSTRUCTIONS)
        val thumbIndex = cursor.getColumnIndex(COLUMN_THUMB)
        val favoriteIndex = cursor.getColumnIndex(COLUMN_FAVORITE)

        if (idIndex != -1 && nameIndex != -1 && categoryIndex != -1 && areaIndex != -1 &&
            instructionsIndex != -1 && thumbIndex != -1 && favoriteIndex != -1) {

            if (cursor.moveToFirst()) {
                do {
                    val recipe = Recipe(
                        idMeal = cursor.getString(idIndex),
                        strMeal = cursor.getString(nameIndex),
                        strCategory = cursor.getString(categoryIndex),
                        strArea = cursor.getString(areaIndex),
                        strInstructions = cursor.getString(instructionsIndex),
                        strMealThumb = cursor.getString(thumbIndex),
                        isFavorite = cursor.getInt(favoriteIndex) == 1
                    )
                    recipes.add(recipe)
                } while (cursor.moveToNext())
            }
        } else {
            Log.e("DatabaseHelper", "One or more columns not found")
        }

        cursor.close()
        db.close()
        return recipes
    }
}
