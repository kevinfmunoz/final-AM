package com.example.res

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExploreActivity : AppCompatActivity() {

    private lateinit var spinnerCategories: Spinner
    private lateinit var recyclerViewRecipes: RecyclerView
    private lateinit var recipesAdapter: RecipesAdapter
    private val apiService = ApiClient.apiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_explore)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        spinnerCategories = findViewById(R.id.spinnerCategories)
        recyclerViewRecipes = findViewById(R.id.recyclerViewRecipes)

        recyclerViewRecipes.layoutManager = LinearLayoutManager(this)

        recipesAdapter = RecipesAdapter(
            emptyList(),
            onRecipeClick = { recipe ->
                onRecipeClicked(recipe)
            },
            onEditClick = { recipe ->
                val intent = Intent(this, EditRecipeActivity::class.java).apply {
                    putExtra("recipe", recipe)
                }
                startActivity(intent)
            },
            onDeleteClick = { recipe ->
            }
        )
        recyclerViewRecipes.adapter = recipesAdapter

        loadCategories()
    }

    private fun loadCategories() {
        apiService.getCategories().enqueue(object : Callback<CategoryResponse> {
            override fun onResponse(call: Call<CategoryResponse>, response: Response<CategoryResponse>) {
                if (response.isSuccessful) {
                    val categories = response.body()?.categories ?: emptyList()
                    val categoryNames = categories.map { it.strCategory }
                    val adapter = ArrayAdapter(this@ExploreActivity, android.R.layout.simple_spinner_item, categoryNames)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinnerCategories.adapter = adapter

                    spinnerCategories.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                            val selectedCategory = categoryNames[position]
                            loadRecipes(selectedCategory)
                        }

                        override fun onNothingSelected(parent: AdapterView<*>) {
                        }
                    }
                }
            }

            override fun onFailure(call: Call<CategoryResponse>, t: Throwable) {
            }
        })
    }

    private fun loadRecipes(category: String) {
        apiService.getRecipesByCategory(category).enqueue(object : Callback<RecipeResponse> {
            override fun onResponse(call: Call<RecipeResponse>, response: Response<RecipeResponse>) {
                if (response.isSuccessful) {
                    val recipes = response.body()?.meals ?: emptyList()
                    recipesAdapter.updateRecipes(recipes)
                }
            }

            override fun onFailure(call: Call<RecipeResponse>, t: Throwable) {
            }
        })
    }

    private fun onRecipeClicked(recipe: Recipe) {
        val intent = Intent(this, RecipeDetailsActivity::class.java).apply {
            putExtra("recipeId", recipe.idMeal)
        }
        startActivity(intent)
    }
}
