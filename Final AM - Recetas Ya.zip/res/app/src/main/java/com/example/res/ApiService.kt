package com.example.res

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("filter.php")
    fun getRecipesByCategory(@Query("c") category: String): Call<RecipeResponse>

    @GET("categories.php")
    fun getCategories(): Call<CategoryResponse>

    @GET("lookup.php")
    fun getRecipeDetails(@Query("i") id: String): Call<RecipeResponse>
}
