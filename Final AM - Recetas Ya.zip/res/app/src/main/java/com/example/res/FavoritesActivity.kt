package com.example.res

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.res.databinding.ActivityFavoritesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FavoritesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritesBinding
    private lateinit var recipeDatabase: RecipeDatabase
    private lateinit var adapter: RecipesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        recipeDatabase = RecipeDatabase.getDatabase(this)

        setupRecyclerView()

        showFavoriteRecipes()
    }

    private fun setupRecyclerView() {
        adapter = RecipesAdapter(
            emptyList(),
            onRecipeClick = { recipe ->
                onRecipeClicked(recipe)
            },
            onEditClick = { recipe ->
                val intent = Intent(this, EditRecipeActivity::class.java).apply {
                    putExtra("recipe", recipe)
                }
                startActivity(intent)
            },
            onDeleteClick = { recipe ->
                deleteRecipe(recipe)
            }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun showFavoriteRecipes() {
        GlobalScope.launch(Dispatchers.IO) {
            val favoriteRecipes = recipeDatabase.recipeDao().getFavoriteRecipes()
            withContext(Dispatchers.Main) {
                if (favoriteRecipes.isNotEmpty()) {
                    adapter.updateRecipes(favoriteRecipes)
                } else {
                    showError("No hay recetas favoritas")
                }
            }
        }
    }

    private fun onRecipeClicked(recipe: Recipe) {
        val intent = Intent(this, RecipeDetailsActivity::class.java).apply {
            putExtra("recipeId", recipe.idMeal)
        }
        startActivity(intent)
    }

    private fun deleteRecipe(recipe: Recipe) {

        GlobalScope.launch(Dispatchers.IO) {
            recipeDatabase.recipeDao().deleteRecipe(recipe)
            withContext(Dispatchers.Main) {
                showFavoriteRecipes()
                showError("Receta eliminada")
            }
        }
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
