package com.example.res

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.widget.Toolbar // Usa androidx.appcompat.widget.Toolbar en lugar de android.widget.Toolbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnExplore: Button = findViewById(R.id.btnExplore)
        val btnAddRecipe: Button = findViewById(R.id.btnAddRecipe)
        val btnFavorites: Button = findViewById(R.id.btnFavorites)
        val btnUserRecipes: Button = findViewById(R.id.btnUserRecipes)


        btnExplore.setOnClickListener {
            val intent = Intent(this, ExploreActivity::class.java)
            startActivity(intent)
        }

        btnAddRecipe.setOnClickListener {
            val intent = Intent(this, AddRecipeActivity::class.java)
            startActivity(intent)
        }

        btnFavorites.setOnClickListener {
            val intent = Intent(this, FavoritesActivity::class.java)
            startActivity(intent)
        }

        btnUserRecipes.setOnClickListener {
            val intent = Intent(this, UserRecipesActivity::class.java)
            startActivity(intent)
        }
    }
}
