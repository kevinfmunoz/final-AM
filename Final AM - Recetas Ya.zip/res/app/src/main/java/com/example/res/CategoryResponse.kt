package com.example.res

data class CategoryResponse(
    val categories: List<Category>
)
