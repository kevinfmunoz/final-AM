package com.example.res

import android.app.Application

class MyApp : Application() {
    val database: RecipeDatabase by lazy { RecipeDatabase.getDatabase(this) }
}
