package com.example.res

data class RecipeResponse(
    val meals: List<Recipe>
)
