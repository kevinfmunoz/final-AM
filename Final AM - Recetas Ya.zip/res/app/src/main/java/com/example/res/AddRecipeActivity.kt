package com.example.res

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.example.res.databinding.ActivityAddRecipeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class AddRecipeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddRecipeBinding
    private lateinit var recipeDatabase: RecipeDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddRecipeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        recipeDatabase = RecipeDatabase.getDatabase(this)

        binding.btnSaveRecipe.setOnClickListener {
            saveRecipe()
        }
    }

    private fun saveRecipe() {
        val recipeName = binding.etRecipeName.text.toString()
        val recipeCategory = binding.etRecipeCategory.text.toString()
        val recipeArea = binding.etRecipeArea.text.toString()
        val recipeInstructions = binding.etRecipeInstructions.text.toString()
        val recipeImage = binding.etRecipeImage.text.toString()

        if (recipeName.isNotBlank() && recipeCategory.isNotBlank() && recipeArea.isNotBlank() && recipeInstructions.isNotBlank() && recipeImage.isNotBlank()) {
            val newRecipe = Recipe(
                idMeal = generateUniqueId(),
                strMeal = recipeName,
                strCategory = recipeCategory,
                strArea = recipeArea,
                strInstructions = recipeInstructions,
                strMealThumb = recipeImage,
                isFavorite = false,
                isUserCreated = true
            )

            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    recipeDatabase.recipeDao().insertRecipe(newRecipe)
                    val insertedRecipe = recipeDatabase.recipeDao().getRecipeById(newRecipe.idMeal)

                    withContext(Dispatchers.Main) {
                        if (insertedRecipe != null) {
                            Toast.makeText(this@AddRecipeActivity, "Receta creada exitosamente", Toast.LENGTH_SHORT).show()
                            setResult(Activity.RESULT_OK, Intent().apply {
                                putExtra("newRecipe", newRecipe)
                            })
                            finish()
                        } else {
                            showError("Error al crear la receta")
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        showError("Error al guardar la receta: ${e.message}")
                    }
                }
            }
        } else {
            showError("Todos los campos son obligatorios")
        }
    }

    private fun generateUniqueId(): String {
        return UUID.randomUUID().toString()
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
