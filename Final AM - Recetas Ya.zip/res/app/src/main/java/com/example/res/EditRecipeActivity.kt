package com.example.res

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.res.databinding.ActivityEditRecipeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditRecipeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditRecipeBinding
    private lateinit var recipeDatabase: RecipeDatabase
    private var recipe: Recipe? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditRecipeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        recipeDatabase = RecipeDatabase.getDatabase(this)

        recipe = intent.getParcelableExtra("recipe")

        if (recipe == null) {
            Toast.makeText(this, "Error: receta no encontrada", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        recipe?.let {
            binding.etRecipeName.setText(it.strMeal)
            binding.etRecipeCategory.setText(it.strCategory)
            binding.etRecipeArea.setText(it.strArea)
            binding.etRecipeInstructions.setText(it.strInstructions)
            binding.etRecipeImage.setText(it.strMealThumb)
        }

        binding.btnSave.setOnClickListener {
            saveRecipe()
        }

        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun saveRecipe() {
        val name = binding.etRecipeName.text.toString()
        val category = binding.etRecipeCategory.text.toString()
        val area = binding.etRecipeArea.text.toString()
        val instructions = binding.etRecipeInstructions.text.toString()
        val imageUrl = binding.etRecipeImage.text.toString()

        if (name.isBlank() || category.isBlank() || area.isBlank() || instructions.isBlank() || imageUrl.isBlank()) {
            Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedRecipe = recipe?.copy(
            strMeal = name,
            strCategory = category,
            strArea = area,
            strInstructions = instructions,
            strMealThumb = imageUrl
        )

        updatedRecipe?.let {
            GlobalScope.launch(Dispatchers.IO) {
                try {
                    recipeDatabase.recipeDao().updateRecipe(it)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@EditRecipeActivity, "Receta actualizada", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@EditRecipeActivity, "Error al actualizar receta", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
