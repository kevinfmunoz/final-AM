package com.example.res

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.res.databinding.ActivityUserRecipesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UserRecipesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserRecipesBinding
    private lateinit var recipesAdapter: RecipesAdapter
    private lateinit var recipeDatabase: RecipeDatabase


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserRecipesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        recipeDatabase = RecipeDatabase.getDatabase(this)

        setupRecyclerView()

        loadUserRecipes()
    }

    private fun setupRecyclerView() {
        recipesAdapter = RecipesAdapter(
            emptyList(),
            onRecipeClick = { recipe ->
                val intent = Intent(this, RecipeDetailsActivity::class.java).apply {
                    putExtra("recipeId", recipe.idMeal)
                }
                startActivity(intent)
            },
            onEditClick = { recipe ->
                val intent = Intent(this, EditRecipeActivity::class.java).apply {
                    putExtra("recipe", recipe)
                }
                startActivity(intent)
            },
            onDeleteClick = { recipe ->
                deleteRecipe(recipe)
            }
        )

        binding.recyclerViewUserRecipes.apply {
            layoutManager = LinearLayoutManager(this@UserRecipesActivity)
            adapter = recipesAdapter
        }
    }

    private fun loadUserRecipes() {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val recipes = recipeDatabase.recipeDao().getUserCreatedRecipes()
                withContext(Dispatchers.Main) {
                    if (recipes.isNotEmpty()) {
                        recipesAdapter.updateRecipes(recipes)
                    } else {
                        showError("No hay recetas guardadas")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error al cargar recetas: ${e.message}")
                }
            }
        }
    }

    private fun deleteRecipe(recipe: Recipe) {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                recipeDatabase.recipeDao().deleteRecipe(recipe)
                val updatedRecipes = recipeDatabase.recipeDao().getUserCreatedRecipes()
                withContext(Dispatchers.Main) {
                    recipesAdapter.updateRecipes(updatedRecipes)
                    showError("Receta eliminada")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error al eliminar receta: ${e.message}")
                }
            }
        }
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
