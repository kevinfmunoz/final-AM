package com.example.res

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import coil.load

@BindingAdapter("imageUrl")
fun bindImage(imageView: ImageView, url: String?) {
    imageView.load(url) {
    }
}
