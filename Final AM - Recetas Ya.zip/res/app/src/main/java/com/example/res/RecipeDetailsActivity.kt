package com.example.res

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.res.databinding.ActivityRecipeDetailsBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RecipeDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecipeDetailsBinding
    private val baseUrl = "https://www.themealdb.com/api/json/v1/1/"
    private lateinit var recipeDatabase: RecipeDatabase
    private var currentRecipe: Recipe? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecipeDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        recipeDatabase = RecipeDatabase.getDatabase(this)

        val recipeId = intent.getStringExtra("recipeId") ?: return
        fetchRecipeDetails(recipeId)

        binding.btnFavorite.setOnClickListener {
            currentRecipe?.let { recipe ->
                toggleFavorite(recipe)
            }
        }
    }

    private fun fetchRecipeDetails(recipeId: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)
        apiService.getRecipeDetails(recipeId).enqueue(object : Callback<RecipeResponse> {
            override fun onResponse(call: Call<RecipeResponse>, response: Response<RecipeResponse>) {
                if (isFinishing || isDestroyed) return

                if (response.isSuccessful) {
                    val recipe = response.body()?.meals?.get(0)
                    if (recipe != null) {
                        currentRecipe = recipe
                        binding.tvRecipeName.text = recipe.strMeal
                        binding.tvRecipeCategory.text = recipe.strCategory
                        binding.tvRecipeArea.text = recipe.strArea
                        binding.tvRecipeInstructions.text = recipe.strInstructions

                        Glide.with(this@RecipeDetailsActivity)
                            .load(recipe.strMealThumb)
                            .apply(RequestOptions()
                                .placeholder(R.drawable.placeholder_image)
                                .error(R.drawable.error_image))
                            .into(binding.ivRecipeImage)

                        updateFavoriteButton(recipe.isFavorite)
                    } else {
                        showError("Receta no encontrada")
                    }
                } else {
                    showError("Error en la respuesta")
                }
            }

            override fun onFailure(call: Call<RecipeResponse>, t: Throwable) {
                if (isFinishing || isDestroyed) return
                showError("Error de red")
            }
        })
    }

    private fun toggleFavorite(recipe: Recipe) {
        recipe.isFavorite = !recipe.isFavorite
        GlobalScope.launch(Dispatchers.IO) {
            if (recipe.isFavorite) {
                val existingRecipe = recipeDatabase.recipeDao().getRecipeById(recipe.idMeal)
                if (existingRecipe == null) {
                    recipeDatabase.recipeDao().insertRecipe(recipe)
                } else {
                    recipeDatabase.recipeDao().updateRecipe(recipe)
                }
                withContext(Dispatchers.Main) {
                    if (!isFinishing && !isDestroyed) {
                        Toast.makeText(this@RecipeDetailsActivity, "Añadido a favoritos", Toast.LENGTH_SHORT).show()
                        updateFavoriteButton(true)
                    }
                }
            } else {
                recipeDatabase.recipeDao().deleteRecipe(recipe)
                withContext(Dispatchers.Main) {
                    if (!isFinishing && !isDestroyed) {
                        Toast.makeText(this@RecipeDetailsActivity, "Eliminado de favoritos", Toast.LENGTH_SHORT).show()
                        updateFavoriteButton(false)
                    }
                }
            }
        }
    }

    private fun updateFavoriteButton(isFavorite: Boolean) {
        if (!isFinishing && !isDestroyed) {
            binding.btnFavorite.text = if (isFavorite) "Eliminar de Favoritos" else "Marcar como Favorito"
        }
    }

    private fun showError(message: String) {
        if (!isFinishing && !isDestroyed) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
}
